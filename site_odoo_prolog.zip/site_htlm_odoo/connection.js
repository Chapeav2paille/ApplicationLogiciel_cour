

const URL_PROXY = "http://localhost:5274/odoo-proxy";
const BASE_DE_DONNEES = "db";
const UTILISATEUR = "soufiane.smahi@hainaut-ea.be";
const MOT_DE_PASSE = "root";

let monIdOdoo = null;
let listeProduits = [];

async function connexionOdoo() {
    try {
        const reponse = await fetch(URL_PROXY, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: {
                    service:"common",
                    method:"login",
                    args: [BASE_DE_DONNEES, UTILISATEUR, MOT_DE_PASSE]
                },
                id: 1
            })
        });

        const data = await reponse.json();
        monIdOdoo = data.result;
        console.log(data);

        if (monIdOdoo) {
            console.log("Super, connecté avec l'ID :", monIdOdoo);
            await chargerProduitsOdoo(); 
        }
    } catch (e) {
        console.log("Erreur de connexion", e);
    }
}


async function chargerProduitsOdoo() {
    const reponse = await fetch(URL_PROXY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            jsonrpc: "2.0",
            method: "call",
            params: {
                service: "object",
                method: "execute_kw",
                args: [
                    BASE_DE_DONNEES, monIdOdoo, MOT_DE_PASSE,
                    "product.product", "search_read",
                    [[]],
                    { fields: ["id", "name", "list_price"], limit: 12 }
                ]
            },
            id: 2
        })
    });

    const data = await reponse.json();
    listeProduits = data.result;
    afficherLesProduits();
}

// partie pour l'affichage html (note le detail de la fonct dans la docu pdf)

function afficherLesProduits() {
    const zoneProduits = document.getElementById("products");
    zoneProduits.innerHTML = "";

    listeProduits.forEach(p => {
        const carte = document.createElement("div");
        carte.className = "product-card";
        carte.innerHTML = `
            <h3>${p.name}</h3>
            <p>Prix : ${p.list_price} €</p>
            <button onclick="faireUneCommande(${p.id})">Acheter</button>
        `;
        zoneProduits.appendChild(carte);
    });
}

// pour créer le devis dans odoo ajt dans la doc piur git

async function faireUneCommande(idArticle) {
    const resOrder = await fetch(URL_PROXY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            jsonrpc: "2.0",
            method: "call",
            params: {
                service: "object",
                method: "execute_kw",
                args: [
                    BASE_DE_DONNEES, monIdOdoo, MOT_DE_PASSE,
                    "sale.order", "create",
                    [{ partner_id: 1 }] 
                ]
            },
            id: 3
        })
    });

    const dataOrder = await resOrder.json();
    const idCommandeCree = dataOrder.result;

//ajouter la ligne (ici je mets prix_unit manuellement)
    const produitChoisi = listeProduits.find(item => item.id === idArticle);
    
    await fetch(URL_PROXY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            jsonrpc: "2.0",
            method: "call",
            params: {
                service: "object",
                method: "execute_kw",
                args: [
                    BASE_DE_DONNEES, monIdOdoo, MOT_DE_PASSE,
                    "sale.order.line", "create",
                    [{
                        order_id: idCommandeCree,
                        product_id: idArticle,
                        product_uom_qty: 1,
                        price_unit: produitChoisi.list_price
                    }]
                ]
            },
            id: 4
        })
    });

    alert("Commande envoyée ! Redirection...");
    window.location.href = "commande.html";
}

connexionOdoo();