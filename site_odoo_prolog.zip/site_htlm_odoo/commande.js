
const URL_PROXY = "http://localhost:5274/odoo-proxy";
const DB = "db";
const USER = "soufiane.smahi@hainaut-ea.be";
const PASS = "root";

let uidConnexion = null;

// liste des diffenrent etat de la commande 

function traduireEtat(etatOdoo) {
    if (etatOdoo === 'draft') return "Brouillon";if (etatOdoo === 'sale') return "Confirmé";if (etatOdoo === 'done') return "Terminé";
    return etatOdoo;
}


async function loginPourSuivi() {
    const res= await fetch(URL_PROXY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            jsonrpc: "2.0", method: "call",
            params: { service: "common", method: "login", args: [DB, USER, PASS] },
            id: 10
        })
    });
    const d = await res.json();
    uidConnexion = d.result;
    
    if (uidConnexion) {
        recupererCommandes();
    }
}

// bien l'expliquer celle la en pdf

async function recupererCommandes() {
    const res = await fetch(URL_PROXY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            jsonrpc: "2.0",
            method: "call",
            params: {
                service: "object",
                method: "execute_kw",
                args: [
                    DB, uidConnexion, PASS,
                    "sale.order", "search_read",
                    [[]],
                    { fields: ["name", "state", "amount_total"], limit: 10 }
                ]
            },
            id: 11
        })
    });

    const data = await res.json();
    const zoneListe = document.getElementById("orders-container");
    zoneListe.innerHTML = "";

    data.result.forEach(com => {
        const ligne = document.createElement("div");
        ligne.style.padding = "15px";
        ligne.style.borderBottom = "1px solid #000";
        ligne.innerHTML = `
            <strong>Numéro : ${com.name}</strong><br>
            Total : ${com.amount_total} €<br>
            Statut : ${traduireEtat(com.state)}
        `;
        zoneListe.appendChild(ligne);
    });
}


loginPourSuivi();