using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http;

var builder = WebApplication.CreateBuilder(args);

// Activer CORS (pour le navigateur)
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors();

// Endpoint proxy vers Odoo
app.MapPost("/odoo-proxy", async (HttpContext context) =>
{
    using var client = new HttpClient();

    var body = await new StreamReader(context.Request.Body).ReadToEndAsync();

    var request = new HttpRequestMessage(
        HttpMethod.Post,
        "http://localhost:8069/jsonrpc"
    );

    request.Content = new StringContent(
        body,
        System.Text.Encoding.UTF8,
        "application/json"
    );

    var response = await client.SendAsync(request);
    var responseBody = await response.Content.ReadAsStringAsync();

    context.Response.ContentType = "application/json";
    await context.Response.WriteAsync(responseBody);
});

app.Run();
